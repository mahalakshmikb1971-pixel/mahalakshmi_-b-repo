-- ============================================================
-- AI-Based Renewable and Sustainable Energy Management System
-- Database Schema
-- ============================================================

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    location TEXT DEFAULT 'Chennai, India',
    solar_capacity REAL DEFAULT 5.0,       -- kWp installed
    grid_rate REAL DEFAULT 8.0,            -- ₹ per kWh
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Weather records
CREATE TABLE IF NOT EXISTS weather_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    hour INTEGER NOT NULL,                  -- 0-23
    temperature REAL,                       -- °C
    humidity REAL,                          -- %
    cloud_cover REAL,                       -- %
    wind_speed REAL,                        -- km/h
    condition TEXT,                         -- Sunny, Cloudy, Rainy etc.
    uv_index REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Solar energy predictions and actuals
CREATE TABLE IF NOT EXISTS solar_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    hour INTEGER NOT NULL,
    predicted_kwh REAL DEFAULT 0.0,
    actual_kwh REAL DEFAULT 0.0,
    irradiance REAL DEFAULT 0.0,           -- W/m²
    efficiency REAL DEFAULT 0.0,           -- %
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Appliances
CREATE TABLE IF NOT EXISTS appliances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    power_watts REAL NOT NULL,
    category TEXT,                          -- HVAC, Laundry, EV, Water, Kitchen
    priority INTEGER DEFAULT 5,            -- 1=high, 10=low
    flexible_timing INTEGER DEFAULT 1,     -- 1=yes, 0=no
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Appliance usage log
CREATE TABLE IF NOT EXISTS appliance_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    appliance_id INTEGER NOT NULL,
    date DATE NOT NULL,
    start_hour INTEGER NOT NULL,
    duration_hours REAL NOT NULL,
    energy_kwh REAL NOT NULL,
    source TEXT DEFAULT 'grid',            -- 'solar' or 'grid'
    recommended_slot INTEGER DEFAULT 0,   -- 1 if AI recommended, 0 if manual
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (appliance_id) REFERENCES appliances(id)
);

-- Energy monitoring (daily summary)
CREATE TABLE IF NOT EXISTS energy_daily (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    solar_generated_kwh REAL DEFAULT 0.0,
    solar_used_kwh REAL DEFAULT 0.0,
    grid_used_kwh REAL DEFAULT 0.0,
    solar_exported_kwh REAL DEFAULT 0.0,
    total_consumption_kwh REAL DEFAULT 0.0,
    peak_solar_hour INTEGER,
    carbon_saved_kg REAL DEFAULT 0.0,
    bill_amount REAL DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, date)
);

-- Hourly energy monitoring
CREATE TABLE IF NOT EXISTS energy_hourly (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    hour INTEGER NOT NULL,
    solar_kwh REAL DEFAULT 0.0,
    grid_kwh REAL DEFAULT 0.0,
    total_kwh REAL DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Bill records
CREATE TABLE IF NOT EXISTS bills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    month TEXT NOT NULL,                   -- YYYY-MM
    grid_units REAL DEFAULT 0.0,
    rate_per_unit REAL DEFAULT 8.0,
    base_charge REAL DEFAULT 100.0,
    tax_amount REAL DEFAULT 0.0,
    total_amount REAL DEFAULT 0.0,
    solar_savings REAL DEFAULT 0.0,
    generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- AI Recommendations
CREATE TABLE IF NOT EXISTS recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date DATE NOT NULL,
    appliance_id INTEGER,
    recommended_start_hour INTEGER,
    recommended_end_hour INTEGER,
    reason TEXT,
    source TEXT DEFAULT 'solar',
    accepted INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (appliance_id) REFERENCES appliances(id)
);

-- ============================================================
-- Sample Data
-- ============================================================
INSERT OR IGNORE INTO users (username, email, password_hash, full_name, location, solar_capacity, grid_rate)
VALUES (
    'demo',
    'demo@energyai.com',
    'pbkdf2:sha256:600000$demo$8a7d6e5f4c3b2a1e9d8c7b6a5f4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b8a7f6',
    'Demo User',
    'Chennai, India',
    5.0,
    8.0
);
