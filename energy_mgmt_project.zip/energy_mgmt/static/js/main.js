/**
 * EnergyAI — Main JavaScript
 */

// Auto-dismiss flash messages
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.querySelectorAll('.flash').forEach(el => {
      el.style.transition = 'opacity .5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    });
  }, 4000);

  // Mobile sidebar overlay close
  document.addEventListener('click', e => {
    const sidebar = document.getElementById('sidebar');
    if (sidebar && sidebar.classList.contains('open') &&
        !sidebar.contains(e.target) && !e.target.closest('.topbar-toggle')) {
      sidebar.classList.remove('open');
    }
  });
});
